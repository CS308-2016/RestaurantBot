Group A 
Name: (Roll Number)
Shubham Jain: 120050002
Palash Kala: 120050010

Group B
Vikas Garg: 120050017
Amol Agarwal: 120110031


Add a well documented and commented code of your experiments in the respective folders.
