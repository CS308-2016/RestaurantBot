sudo apt-get install python-pip python-dev build-essential
sudo pip install --upgrade pip
pip install django
pip install requests
pip install simplejson
pip install djangorestframework
pip install markdown       # Markdown support for the browsable API.
pip install django-filter  # Filtering support
pip install pyserial
