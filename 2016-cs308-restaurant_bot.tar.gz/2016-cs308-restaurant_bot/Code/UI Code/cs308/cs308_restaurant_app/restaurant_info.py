# This file contains all the constants to be used in restaurant app

NUM_TABLES=16
NUM_DISHES=4

NUM_BOTS=2
NUM_POSITIONS=2