from __future__ import unicode_literals

from django.apps import AppConfig


class Cs308RestaurantAppConfig(AppConfig):
    name = 'cs308_restaurant_app'
