Project Name:

Team Members:
1.	Shubham Jain (120050002)
2.	Palash Kala  (120050010)
3.	Vikas Garg 	 (120050017)
4.  Amol Agarwal (120110031) 

####################################################################################
NOTE:

READ InstallationScreencast.pdf in this folder

####################################################################################

Project Description:
When we order our food in restaurants, it sometimes takes a lot of time to deliver because of inefficiency of waiters and we have to wait for waiters to deliver our food even it is cooked.
Also it’s costly for restaurant owners to put more and more waiters. The waiters expect a tip from the customers and this goes to about 10-15% of the bill amount in the US.
Moreover when there is heavy load, there’s a lot of chaos, with same order being repeated multiple times to different waiters.
Our solution to this problem is having restaurent bots instead of waiters to deliver the food to customer. 
People can order through an interface (An app or a web interface).
Food will be prepared accordingly and given to our restaurant bot. 
We will use line follower model of moving on white line on black surface for demo purposes . For controlling multiple bots, we have a central system, which will decide the path for every bot. For every table we can have a position where the bot will reach and customer will take the food from the bot. 